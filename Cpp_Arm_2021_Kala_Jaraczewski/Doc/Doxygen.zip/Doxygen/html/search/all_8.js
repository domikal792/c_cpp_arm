var searchData=
[
  ['refreshscreen_0',['RefreshScreen',['../class_monochrome_graphic_display_1_1_display_driver_if.html#a42f8b8a93630b3f57baa441ccc136a05',1,'MonochromeGraphicDisplay::DisplayDriverIf']]],
  ['reset_1',['Reset',['../class_display_comm_1_1_display_reset_if.html#a3a575063dc35088cb40d83398e3e9d1d',1,'DisplayComm::DisplayResetIf']]]
];
