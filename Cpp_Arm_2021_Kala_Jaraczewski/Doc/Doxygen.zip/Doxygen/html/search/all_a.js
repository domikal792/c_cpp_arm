var searchData=
[
  ['turnoffdisplay_0',['TurnOffDisplay',['../class_monochrome_graphic_display_1_1_display_driver_if.html#ad555a9ac06265fa48f7b16dad90d9137',1,'MonochromeGraphicDisplay::DisplayDriverIf']]],
  ['turnondisplay_1',['TurnOnDisplay',['../class_monochrome_graphic_display_1_1_display_driver_if.html#aec24ab8cf401c0a162b05b8a6baea232',1,'MonochromeGraphicDisplay::DisplayDriverIf']]]
];
