var searchData=
[
  ['setcontrast_0',['SetContrast',['../class_monochrome_graphic_display_1_1_display_driver_if.html#ab7728eb550cc3ef4610baff27079ee63',1,'MonochromeGraphicDisplay::DisplayDriverIf']]],
  ['setpixelcolor_1',['SetPixelColor',['../class_monochrome_view_1_1_dynamic_view.html#a13b3ec36a9c080bf072f517f8f978f88',1,'MonochromeView::DynamicView']]]
];
