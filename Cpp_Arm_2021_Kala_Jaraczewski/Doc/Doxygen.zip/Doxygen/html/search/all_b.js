var searchData=
[
  ['viewif_0',['ViewIf',['../class_monochrome_view_1_1_view_if.html',1,'MonochromeView']]],
  ['viewif_2ehpp_1',['ViewIf.hpp',['../_view_if_8hpp.html',1,'']]]
];
