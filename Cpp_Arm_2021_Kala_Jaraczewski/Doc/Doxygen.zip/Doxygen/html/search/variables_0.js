var searchData=
[
  ['draw_5fopt_5fnegative_5fcolors_0',['DRAW_OPT_NEGATIVE_COLORS',['../_dynamic_view_8hpp.html#a2330978f653bd00d6e0bb222dbb03e73',1,'MonochromeView']]],
  ['draw_5fopt_5fnone_1',['DRAW_OPT_NONE',['../_dynamic_view_8hpp.html#a7ccb70d3b86ee933ba2bcaf6f4e40f34',1,'MonochromeView']]],
  ['draw_5fopt_5ftranspose_2',['DRAW_OPT_TRANSPOSE',['../_dynamic_view_8hpp.html#a4fab354e5dbc3ccf9a3b6c6377a07337',1,'MonochromeView']]],
  ['draw_5fopt_5fx_5fmirror_3',['DRAW_OPT_X_MIRROR',['../_dynamic_view_8hpp.html#ab1061032e56ea93964e85e0189369453',1,'MonochromeView']]],
  ['draw_5fopt_5fy_5fmirror_4',['DRAW_OPT_Y_MIRROR',['../_dynamic_view_8hpp.html#aa4f428ab9075c0fd2bc19bbaed807256',1,'MonochromeView']]]
];
