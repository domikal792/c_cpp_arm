var searchData=
[
  ['ifviewchanged_0',['IfViewChanged',['../class_monochrome_view_1_1_const_view.html#a4ae0a5909fbfa554bafe359b60eb18e0',1,'MonochromeView::ConstView::IfViewChanged()'],['../class_monochrome_view_1_1_dynamic_view.html#a8ea08ee20d867fe617d2e4ff733f13c2',1,'MonochromeView::DynamicView::IfViewChanged()'],['../class_monochrome_view_1_1_view_if.html#a66769ee33f3d2188306fc961fdde9e03',1,'MonochromeView::ViewIf::IfViewChanged()']]],
  ['inversecolor_1',['InverseColor',['../class_monochrome_graphic_display_1_1_display_driver_if.html#ae1aa010e9bead7d83655ec0e9f602425',1,'MonochromeGraphicDisplay::DisplayDriverIf']]]
];
